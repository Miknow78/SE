package com.example.bluetoothcontrol

import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import android.bluetooth.BluetoothSocket
import android.util.Log
import kotlinx.android.synthetic.main.content_main.*
import kotlinx.android.synthetic.main.control_layout.*
import java.io.IOException
import kotlin.math.log

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class ControlActivity: AppCompatActivity() {

    companion object{
        var myUUID: UUID = UUID.fromString("636c49b4-af9b-11ea-b3de-0242ac130004") // UUID...
        var bluetoothSocket: BluetoothSocket? = null
        lateinit var progress: ProgressDialog // melhor maneira mesmo dando com traço por cima!
        lateinit var bluetoothAdapter: BluetoothAdapter
        var isConnected: Boolean = false
        lateinit var address: String // MAC ADDRESS

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.control_layout)
        address = intent.getStringExtra(SelectDeviceActivity.EXTRAS_ADDRESS) // ir buscar MAC address a outra pagina

        ConnectToDevice(this).execute()

        control_led_on.setOnClickListener { Command("0") }
        control_led_off.setOnClickListener { Command("1") }
        control_disconnect.setOnClickListener { desconectar() }
    }
    private fun Command(input: String){
        if (bluetoothSocket != null){
            try{
                bluetoothSocket!!.outputStream.write(input.toByteArray()) // mandar comando para arduino
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun desconectar(){
        if(bluetoothSocket != null){
            try {
                bluetoothSocket!!.close()
                bluetoothSocket = null
                isConnected = false
            }catch (e: IOException) {
                e.printStackTrace()
            }
        }
        finish()
    }

    private class ConnectToDevice(c: Context) : AsyncTask<Void, Void, String>(){
        private val connectSuccess: Boolean = true
        private val context: Context

        init {
            this.context = 0 // Inicio de App
        }

        override fun onPreExecute() {
            super.onPreExecute()
            progress = ProgressDialog.show(context, "Conetando...", "aguarde")
        }

        override fun doInBackground(vararg params: Void?): String {
            try{
                if(bluetoothSocket == null || !isConnected){
                    bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    val device: BluetoothDevice = bluetoothAdapter.getRemoteDevice(address)
                    bluetoothSocket = device.createInsecureRfcommSocketToServiceRecord(myUUID)
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    bluetoothSocket!!.connect()
                }
            }catch (e:IOException){
                connectSuccess=false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!connectSuccess) {
                Log.i("data", "Falha a conectar")
            } else {
                isConnected = true
            }
            progress.dismiss()
        }
    }
}